import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-boys',
  templateUrl: './delivery-boys.component.html',
  styleUrls: ['./delivery-boys.component.css']
})
export class DeliveryBoysComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
