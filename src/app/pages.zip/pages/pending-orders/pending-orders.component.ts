import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-orders',
  templateUrl: './pending-orders.component.html',
  styleUrls: ['./pending-orders.component.css']
})
export class PendingOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
