import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-cash-payments',
  templateUrl: './view-cash-payments.component.html',
  styleUrls: ['./view-cash-payments.component.css']
})
export class ViewCashPaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
