import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCashPaymentsComponent } from './view-cash-payments.component';

describe('ViewCashPaymentsComponent', () => {
  let component: ViewCashPaymentsComponent;
  let fixture: ComponentFixture<ViewCashPaymentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewCashPaymentsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewCashPaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
