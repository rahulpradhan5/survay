# Jar-app-admin-pannel
Jar-app-admin-pannel made in angular for run intialize command npm installl after is write ng serve --open
