import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-sub-category',
  templateUrl: './add-sub-category.component.html',
  styleUrls: ['./add-sub-category.component.css']
})
export class AddSubCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
