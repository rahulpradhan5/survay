import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-online-payments',
  templateUrl: './view-online-payments.component.html',
  styleUrls: ['./view-online-payments.component.css']
})
export class ViewOnlinePaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
