import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-range-driver',
  templateUrl: './order-range-driver.component.html',
  styleUrls: ['./order-range-driver.component.css']
})
export class OrderRangeDriverComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
