import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderRangeDriverComponent } from './order-range-driver.component';

describe('OrderRangeDriverComponent', () => {
  let component: OrderRangeDriverComponent;
  let fixture: ComponentFixture<OrderRangeDriverComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrderRangeDriverComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrderRangeDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
