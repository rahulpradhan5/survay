import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstantOrderStatusComponent } from './instant-order-status.component';

describe('InstantOrderStatusComponent', () => {
  let component: InstantOrderStatusComponent;
  let fixture: ComponentFixture<InstantOrderStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstantOrderStatusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InstantOrderStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
