import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instant-order-status',
  templateUrl: './instant-order-status.component.html',
  styleUrls: ['./instant-order-status.component.css']
})
export class InstantOrderStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
