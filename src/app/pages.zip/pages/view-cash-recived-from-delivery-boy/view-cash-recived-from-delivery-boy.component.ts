import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-cash-recived-from-delivery-boy',
  templateUrl: './view-cash-recived-from-delivery-boy.component.html',
  styleUrls: ['./view-cash-recived-from-delivery-boy.component.css']
})
export class ViewCashRecivedFromDeliveryBoyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
