import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCashRecivedFromDeliveryBoyComponent } from './view-cash-recived-from-delivery-boy.component';

describe('ViewCashRecivedFromDeliveryBoyComponent', () => {
  let component: ViewCashRecivedFromDeliveryBoyComponent;
  let fixture: ComponentFixture<ViewCashRecivedFromDeliveryBoyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewCashRecivedFromDeliveryBoyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewCashRecivedFromDeliveryBoyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
