import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejected-orders',
  templateUrl: './rejected-orders.component.html',
  styleUrls: ['./rejected-orders.component.css']
})
export class RejectedOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
