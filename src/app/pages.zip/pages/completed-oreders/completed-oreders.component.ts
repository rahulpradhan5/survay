import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed-oreders',
  templateUrl: './completed-oreders.component.html',
  styleUrls: ['./completed-oreders.component.css']
})
export class CompletedOredersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
