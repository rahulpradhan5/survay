import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompletedOredersComponent } from './completed-oreders.component';

describe('CompletedOredersComponent', () => {
  let component: CompletedOredersComponent;
  let fixture: ComponentFixture<CompletedOredersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompletedOredersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompletedOredersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
