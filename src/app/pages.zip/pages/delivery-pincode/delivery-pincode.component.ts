import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-pincode',
  templateUrl: './delivery-pincode.component.html',
  styleUrls: ['./delivery-pincode.component.css']
})
export class DeliveryPincodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
