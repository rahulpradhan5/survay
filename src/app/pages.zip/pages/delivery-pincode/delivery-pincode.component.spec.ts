import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryPincodeComponent } from './delivery-pincode.component';

describe('DeliveryPincodeComponent', () => {
  let component: DeliveryPincodeComponent;
  let fixture: ComponentFixture<DeliveryPincodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeliveryPincodeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeliveryPincodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
